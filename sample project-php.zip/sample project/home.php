<html>
<head>
<title>Welcome</title>
</head>
<body background="1.jpg">
<center> 
<table bgcolor=white border=0 width=100% height=6%>
<tr><td>
<table>
</table>
<td><table bgcolor=white border=0 width=80%>
<tr><td align=center width=30% font color=red size=5><a href=index.php  style="color:red; text-decoration:none;"><b>Home</b>  
<td align=center width=30% font color=red size=5><a href=aboutas.php    style="color:red; text-decoration:none;"><b>Aboutus</b>
<td align=center width=30% font color=red size=5><a href=registration.php   style="color:red; text-decoration:none;"><b>Add Designs</b>
<td align=center width=30% font color=red size=5><a href=logout.php    style="color:red; text-decoration:none;"><b>Logout</b>
</table>
</table>
</html>